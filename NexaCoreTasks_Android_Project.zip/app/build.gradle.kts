plugins {
    id("com.android.application")
}

android {
    namespace = "com.nexacore.tasks"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nexacore.tasks"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}