package com.nexacore.tasks;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private static final String CHANNEL =
        "https://whatsapp.com/channel/0029VbDMFOI30LKOcocOre3A";

    private LinearLayout root, taskCard;
    private TextView pointsText, statusText;
    private Button actionButton;
    private int points = 0;
    private boolean opened = false;
    private boolean completed = false;

    int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return t;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }

    void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        root.setBackgroundColor(Color.rgb(8,13,25));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("NexaCore Tasks", 22, Color.WHITE, true);
        pointsText = text("⭐ 0 pts", 15, Color.rgb(143,240,201), true);
        bar.addView(logo, new LinearLayout.LayoutParams(0, dp(55), 1));
        bar.addView(pointsText, new LinearLayout.LayoutParams(-2, dp(55)));
        root.addView(bar);

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        TextView title = text("Complete tasks.\nEarn points.", 31, Color.WHITE, true);
        content.addView(title);
        TextView intro = text("Join communities and complete simple tasks to grow your NexaCore points.", 15, Color.rgb(158,171,193), false);
        intro.setPadding(0, dp(8), 0, dp(16));
        content.addView(intro);

        taskCard = new LinearLayout(this);
        taskCard.setOrientation(LinearLayout.VERTICAL);
        taskCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        taskCard.setBackgroundColor(Color.rgb(21,30,49));

        TextView badge = text("+100 POINTS", 12, Color.rgb(131,239,197), true);
        taskCard.addView(badge);

        TextView task = text("💬  Join our WhatsApp Channel", 19, Color.WHITE, true);
        task.setPadding(0, dp(16), 0, dp(6));
        taskCard.addView(task);

        TextView desc = text("Stay updated with NexaCore news, tips and opportunities.", 14, Color.rgb(158,171,193), false);
        taskCard.addView(desc);

        TextView reward = text("Reward:  +100 ⭐", 18, Color.rgb(255,215,106), true);
        reward.setPadding(0, dp(18), 0, dp(12));
        taskCard.addView(reward);

        actionButton = new Button(this);
        actionButton.setText("Join WhatsApp Channel");
        taskCard.addView(actionButton, new LinearLayout.LayoutParams(-1, dp(52)));

        statusText = text("", 13, Color.rgb(203,214,232), false);
        statusText.setPadding(0, dp(12), 0, 0);
        taskCard.addView(statusText);

        actionButton.setOnClickListener(v -> handleTask());

        content.addView(taskCard);
        TextView how = text("HOW IT WORKS", 13, Color.rgb(127,141,165), true);
        how.setPadding(0, dp(28), 0, dp(10));
        content.addView(how);
        TextView steps = text("1. Tap the task button.\n\n2. Join the WhatsApp Channel.\n\n3. Return to NexaCore.\n\n4. Claim your 100 points.", 14, Color.rgb(158,171,193), false);
        content.addView(steps);

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    void handleTask() {
        if (completed) return;

        if (!opened) {
            opened = true;
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(CHANNEL)));
            } catch (Exception e) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.whatsapp.com/")));
            }
            actionButton.setText("Claim 100 points");
            statusText.setText("After joining, return here and tap “Claim 100 points”.");
        } else {
            completed = true;
            points += 100;
            pointsText.setText("⭐ " + points + " pts");
            actionButton.setText("✓ Task completed");
            actionButton.setEnabled(false);
            statusText.setText("🎉 Task completed! You earned 100 points.");
        }
    }
}